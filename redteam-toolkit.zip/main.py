"""Entrypoint: run the whole pipeline against a target."""
from __future__ import annotations

import argparse
import asyncio

import plugins  # noqa: F401  -> registers your payloads/operators on import

from toolkit.config import Config
from toolkit.fliphunter import hunt
from toolkit.metamorphic import check_invariance
from toolkit.registry import build_attacks
from toolkit.report import summarize, write_html
from toolkit.runner import run_suite
from toolkit.semantic import SemanticGate
from toolkit.storage import Storage
from toolkit.target import TargetClient


def _load_seeds(path: str | None):
    if not path:
        return []
    with open(path, encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip()]


async def run(cfg: Config, seeds):
    client = TargetClient(cfg.target_url, cfg.predict_path, cfg.timeout_s)
    gate = SemanticGate(cfg.semantic_model, cfg.semantic_tau)
    store = Storage(cfg.db_path)
    print(f"[*] semantic gate backend: {gate.backend}")

    # 1) static suite (from plugins.py)
    attacks = build_attacks()
    print(f"[*] firing {len(attacks)} static attacks ...")
    results = await run_suite(client, attacks, cfg.concurrency, on_result=store.save_result)

    # 2) flip hunter + 3) invariance oracle (per seed, each guarded)
    flips, invs = [], []
    for seed in seeds:
        try:
            flip = await hunt(client, seed, gate, budget=cfg.query_budget)
            if flip:
                store.save_flip(flip)
            flips.append(flip)
        except Exception as e:
            print(f"[!] flip hunter failed on seed {seed!r} -> {type(e).__name__}: {e}")

        try:
            rep = await check_invariance(client, seed, gate,
                                         conf_drift_threshold=cfg.conf_drift_threshold)
            store.save_invariance(rep)
            invs.append(rep)
            print(f"[*] invariance: seed={seed!r} tested={rep.tested} "
                  f"violations={len(rep.violations)} score={rep.invariance_score:.3f}")
        except Exception as e:
            print(f"[!] invariance failed on seed {seed!r} -> {type(e).__name__}: {e}")

    # 4) report
    summary = summarize(results, flips, invs)
    write_html(summary, cfg.report_path, flips, invs)
    print("[*] summary:", summary)
    print(f"[*] report written to {cfg.report_path}  (db: {cfg.db_path})")

    await client.aclose()
    store.close()


def main():
    ap = argparse.ArgumentParser(description="Adversarial Input Red-Teaming Toolkit")
    ap.add_argument("--url", default=Config.target_url)
    ap.add_argument("--path", default=Config.predict_path)
    ap.add_argument("--seeds", default=None, help="text file, one seed sentence per line")
    ap.add_argument("--budget", type=int, default=Config.query_budget)
    ap.add_argument("--concurrency", type=int, default=Config.concurrency)
    args = ap.parse_args()

    cfg = Config(target_url=args.url, predict_path=args.path,
                 query_budget=args.budget, concurrency=args.concurrency)
    asyncio.run(run(cfg, _load_seeds(args.seeds)))


if __name__ == "__main__":
    main()
