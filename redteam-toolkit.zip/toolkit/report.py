"""Minimal report. This is a placeholder the dashboard will replace/extend —
it exists so the pipeline produces something viewable on Day 1.
"""
from __future__ import annotations

import html
import statistics
from typing import List, Optional

from .fliphunter import FlipResult
from .metamorphic import InvarianceReport
from .models import Result


def summarize(
    results: List[Result],
    flips: Optional[List[Optional[FlipResult]]] = None,
    invariance: Optional[List[InvarianceReport]] = None,
) -> dict:
    total = len(results)
    crashes = [r for r in results if r.finding == "crash"]
    lat = [r.latency_ms for r in results if r.latency_ms]
    flips = [f for f in (flips or []) if f]
    invariance = invariance or []
    return {
        "total_attacks": total,
        "crashes": len(crashes),
        "crash_rate": round(len(crashes) / total, 4) if total else 0.0,
        "latency_p50_ms": round(statistics.median(lat), 1) if lat else 0.0,
        "latency_max_ms": round(max(lat), 1) if lat else 0.0,
        "verified_flips": sum(1 for f in flips if f.verified),
        "flip_attempts": len(flips),
        "invariance_violations": sum(len(r.violations) for r in invariance),
        "avg_invariance_score": round(
            statistics.mean([r.invariance_score for r in invariance]), 4) if invariance else None,
    }


def write_html(summary: dict, path: str,
               flips: Optional[List[Optional[FlipResult]]] = None,
               invariance: Optional[List[InvarianceReport]] = None):
    flips = [f for f in (flips or []) if f and f.verified]
    rows = "".join(f"<tr><td>{html.escape(k)}</td><td>{html.escape(str(v))}</td></tr>"
                   for k, v in summary.items())

    flip_rows = "".join(
        f"<tr><td>{html.escape(f.original)}</td><td>{html.escape(f.adversarial)}</td>"
        f"<td>{html.escape(f.original_label)} &rarr; {html.escape(f.adversarial_label)}</td>"
        f"<td>{f.semantic_similarity:.3f}</td><td>{len(f.edits)}</td></tr>"
        for f in flips) or "<tr><td colspan=5>No verified flips.</td></tr>"

    inv_rows = "".join(
        f"<tr><td>{html.escape(rep.seed)}</td><td>{html.escape(v.operator)}</td>"
        f"<td>{html.escape(v.kind)}</td><td>{html.escape(rep.seed_label)} &rarr; {html.escape(v.variant_label)}</td></tr>"
        for rep in (invariance or []) for v in rep.violations) or "<tr><td colspan=4>No violations.</td></tr>"

    doc = f"""<!doctype html><meta charset=utf-8>
<title>Robustness Report</title>
<style>
 body{{font:14px system-ui;margin:2rem;background:#0b1220;color:#dbe4f0}}
 h1,h2{{color:#5eead4}} table{{border-collapse:collapse;margin:.5rem 0 1.5rem;width:100%}}
 td,th{{border:1px solid #22314f;padding:.4rem .6rem;text-align:left}}
 th{{background:#111c33}}
</style>
<h1>Adversarial Input Robustness Report</h1>
<h2>Summary</h2><table>{rows}</table>
<h2>Verified minimal flips (sensitivity)</h2>
<table><tr><th>Original</th><th>Adversarial</th><th>Label</th><th>Similarity</th><th>Edits</th></tr>{flip_rows}</table>
<h2>Invariance violations (metamorphic)</h2>
<table><tr><th>Seed</th><th>Operator</th><th>Kind</th><th>Label change</th></tr>{inv_rows}</table>
"""
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)
